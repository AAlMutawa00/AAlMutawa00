<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Project DR</title>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>


<form action="norm.php" method="post">

<table>
<tr><td>Sepal Length: </td><td><input name="sl" type="text" width="50" /></td></tr>
<tr><td>Sepal Width: </td><td><input name="sw" type="text" width="50" /></td></tr>
<tr><td>Petal Length: </td><td><input name="pl" type="text" width="50" /></td></tr>
<tr><td>Petal Width: </td><td><input name="pw" type="text" width="50" /></td></tr>
<tr><td>Tolerance: </td><td><input name="var" type="text" width="50" /></td></tr>
</table>
<br />

<button type="submit" value="Submit">Submit</button>
<button type="reset">Reset</button>

</form>
</body>
</html>
