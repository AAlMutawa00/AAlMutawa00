IRIS DSS

Developer: Abhinit Ambastha
abhinit-kumar.ambastha@stud.ki.se
===========================

STEP 1: SETTING UP THE DATABASE

1. In phpmyadmin import the IRIS.csv into the database 'pdr' with table 'table'

2. The fields are sl,sln,sw,swn,pl,pln,flower

3. edit your login details in connect_db.php

STEP 2: EXECUTION

1. run the index.php

2. use the test data in 'IRIS Test data.txt' to test the software


===========================

