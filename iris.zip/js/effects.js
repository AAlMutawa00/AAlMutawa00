
$(document).ready(function(){
	
							 
	$("div#backend").hide();
	 
	  $("#clic").click(function () {
	  $("div#backend").toggle(500);


    }); 
	 
	 
 });
